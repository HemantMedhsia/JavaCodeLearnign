package LibraryManagementSystem.Utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import LibraryManagementSystem.Models.Book;
import LibraryManagementSystem.Models.User;

public class Helper {

    public static User findUserById(String userId, List<User> userList) {
        for(User user: userList) {
            if(user.getUserId().equals(userId)) {
                System.out.println("User found: " + user.getUserName());
                return user;
            }
        }
        return null;
    }

    public static Book findBookById(String bookId, List<Book> bookList) {
        for(Book book: bookList) {
            if(book.getBookId().equals(bookId)) {
                return book;
            }
        }
        return null;
    }

    // public static void loadBooksFromFile(String fileName, Question[] question) {
    //     try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
    //         String line;
    //         int index = 0;
    //         while ((line = br.readLine()) != null && index < 10) {
    //             String[] data = line.split("\\|"); // Split using '|'
    //             if (data.length == 7) {
    //                 question[index] = new Question(
    //                         data[0], data[1], data[2], data[3], data[4], data[5], data[6]);
    //                 index++;
    //             }
    //         }
    //     } catch (IOException e) {
    //         System.out.println("Error reading file: " + e.getMessage());
    //     }
    // }
}
